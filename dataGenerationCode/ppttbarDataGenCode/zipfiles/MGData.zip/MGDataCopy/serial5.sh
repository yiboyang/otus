#!/bin/bash
#$ -N ppttbar2_Seed5_10k
#$ -q free64
#$ -m beas

# Replace "date" with your program. Output goes to out
./process5.sh  > log5.txt

#sleep 60
