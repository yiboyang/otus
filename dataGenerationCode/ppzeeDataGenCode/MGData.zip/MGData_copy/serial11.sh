#!/bin/bash
#$ -N ppzee_full_Seed11_10k
#$ -q free64
#$ -m beas

# Replace "date" with your program. Output goes to out
./process11.sh  > log11.txt

#sleep 60
