#!/bin/bash
#$ -N ppzee_FinalData
#$ -q free64
#$ -m beas

# Replace "date" with your program. Output goes to out
./FinalData_ppzee.sh  > log.txt

#sleep 60
